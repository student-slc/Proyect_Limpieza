<li class="side-menus active">
    <br>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opcion_dash')): ?>
        <a class="nav-link active" href="/home">
            <i class=" fas fa-building"></i><span>Dashboard</span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opcion_user')): ?>
        <a class="nav-link" href="/usuarios">
            <i class=" fas fa-users"></i><span>Usuario</span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opcion_rol')): ?>
        <a class="nav-link" href="/roles">
            <i class=" fas fa-user-lock"></i><span>Roles</span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opcion_chotel')): ?>
        <a class="nav-link" href="/cadenahotelera">
            <i class=" fas fa-city"></i><span>Cadena Hotelera</span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opcion_camar')): ?>
        <a class="nav-link" href="/camaristas">
            <i class=" fas fa-city"></i><span>Camaristas</span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opcion_cuest')): ?>
        <a class="nav-link" href="/cuestionario">
            <i class=" fas fa-question"></i><span>Cuestionario</span>
        </a>
    <?php endif; ?>
</li>
<?php /**PATH C:\laragon\www\proyecto_tickets\resources\views/layouts/menu.blade.php ENDPATH**/ ?>