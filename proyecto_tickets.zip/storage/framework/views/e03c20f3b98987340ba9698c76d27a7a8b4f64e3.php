
    <label id="<?php echo e($name); ?>">Evidencia</label>
    <input name="<?php echo e($name); ?>" class="form-control" type="<?php echo e($type); ?>" >

<?php /**PATH C:\laragon\www\proyecto_tickets\resources\views/components/field.blade.php ENDPATH**/ ?>