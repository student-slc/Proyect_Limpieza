<li class="side-menus <?php echo e(Request::is('home') ? 'active' : ''); ?>">
    <a class="nav-link" href="/">
        <i class=" fas fa-building"></i><span>Dashboard</span>
    </a>
    <a class="nav-link" href="/usuarios">
        <i class=" fas fa-users"></i><span>Usuario</span>
    </a>
    <a class="nav-link" href="/roles">
        <i class=" fas fa-user-lock"></i><span>Roles</span>
    </a>
    <a class="nav-link" href="/blogs">
        <i class=" fas fa-blog"></i><span>Blogs</span>
    </a>
</li>
<?php /**PATH C:\laragon\www\tickets\resources\views/layouts/menu.blade.php ENDPATH**/ ?>