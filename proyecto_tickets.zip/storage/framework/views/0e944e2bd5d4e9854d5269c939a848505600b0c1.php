<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">IMAGENES</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <table class="table table-striped mt-2">
                                <thead style="background-color:#6777ef">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">IMAGEN</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $limpieza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limpiezas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($limpiezas->id); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset($limpiezas->rejunteLimpioFoto)); ?>" alt="Imagen"
                                                    class="img-fluid img-thumbnail" width="100px">
                                                <object type="application/pdf"
                                                    data="<?php echo e(asset($limpiezas->puertaLimpiaFoto)); ?>"
                                                    style="width: 250px; height: 300px;">
                                                    ERROR (no puede mostrarse el objeto)
                                                </object>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_tickets\resources\views/cuestionario/show.blade.php ENDPATH**/ ?>