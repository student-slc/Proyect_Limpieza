<div class="footer-left">
    Derechos Reservados Empresa Virtual
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.1/js/selectize.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.1/js/standalone/selectize.min.js"></script>

<script>
   $('.selectsearch').selectize({
	plugins: ['remove_button'],
	sortField: 'text'
});
</script>
<?php /**PATH C:\laragon\www\proyecto_tickets\resources\views/layouts/footer.blade.php ENDPATH**/ ?>