<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Usuarios</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-usuario')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('usuarios.create')); ?>">Agregar Usuario</a>
                            <?php endif; ?>

                            <table class="table table-striped mt-2">
                                <thead style="background-color:#00C0F5">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Nombre</th>
                                    <th style="color:#fff;">E-mail</th>
                                    <th style="color:#fff;">Hotel</th>
                                    <th style="color:#fff;">Rol</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('todos_hoteles')): ?>
                                        <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($usuarios->id); ?></td>
                                                <td><?php echo e($usuarios->name); ?></td>
                                                <td><?php echo e($usuarios->email); ?></td>
                                                <td><?php echo e($usuarios->hotel); ?></td>
                                                <td>
                                                    <?php if(!empty($usuarios->getRoleNames())): ?>
                                                        <?php $__currentLoopData = $usuarios->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolNombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <h5><span class="badge badge-dark"><?php echo e($rolNombre); ?></span></h5>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <div class="btn-group">
                                                        <a class="btn btn-info"
                                                            href="<?php echo e(route('usuarios.edit', $usuarios->id)); ?>">
                                                            <i class="fas fa-edit"></i></a>

                                                        <?php echo Form::open([
                                                            'method' => 'DELETE',
                                                            'route' => ['usuarios.destroy', $usuarios->id],
                                                            'style' => 'display:inline',
                                                        ]); ?>

                                                        <?php echo Form::button('<i class="fas fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger']); ?>

                                                        <?php echo Form::close(); ?>

                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('por_hotel')): ?>
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('camarista')): ?>
                                            <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($usuarios->rol == 'Camarista'): ?>
                                                    <tr>
                                                        <td style="display: none;"><?php echo e($usuarios->id); ?></td>
                                                        <td><?php echo e($usuarios->name); ?></td>
                                                        <td><?php echo e($usuarios->email); ?></td>
                                                        <td><?php echo e($usuarios->hotel); ?></td>
                                                        <td>
                                                            <?php if(!empty($usuarios->getRoleNames())): ?>
                                                                <?php $__currentLoopData = $usuarios->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolNombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <h5><span class="badge badge-dark"><?php echo e($rolNombre); ?></span>
                                                                    </h5>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </td>

                                                        <td>
                                                            <div class="btn-group">
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-usuario')): ?>
                                                                    <a class="btn btn-info"
                                                                        href="<?php echo e(route('usuarios.edit', $usuarios->id)); ?>">
                                                                        <i class="fas fa-edit"></i></a>
                                                                <?php endif; ?>
                                                                <?php echo Form::open([
                                                                    'method' => 'DELETE',
                                                                    'route' => ['usuarios.destroy', $usuarios->id],
                                                                    'style' => 'display:inline',
                                                                ]); ?>

                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-usuario')): ?>
                                                                    <?php echo Form::button('<i class="fas fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger']); ?>

                                                                <?php endif; ?>
                                                                <?php echo Form::close(); ?>

                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supervisor')): ?>
                                            <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($usuarios->rol == 'Camarista' || $usuarios->rol == 'Supervisor'): ?>
                                                    <tr>
                                                        <td style="display: none;"><?php echo e($usuarios->id); ?></td>
                                                        <td><?php echo e($usuarios->name); ?></td>
                                                        <td><?php echo e($usuarios->email); ?></td>
                                                        <td><?php echo e($usuarios->hotel); ?></td>
                                                        <td>
                                                            <?php if(!empty($usuarios->getRoleNames())): ?>
                                                                <?php $__currentLoopData = $usuarios->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolNombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <h5><span class="badge badge-dark"><?php echo e($rolNombre); ?></span>
                                                                    </h5>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </td>

                                                        <td>
                                                            <div class="btn-group">
                                                                <a class="btn btn-info"
                                                                    href="<?php echo e(route('usuarios.edit', $usuarios->id)); ?>">
                                                                    <i class="fas fa-edit"></i></a>

                                                                <?php echo Form::open([
                                                                    'method' => 'DELETE',
                                                                    'route' => ['usuarios.destroy', $usuarios->id],
                                                                    'style' => 'display:inline',
                                                                ]); ?>

                                                                <?php echo Form::button('<i class="fas fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger']); ?>

                                                                <?php echo Form::close(); ?>

                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gerente')): ?>
                                            <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($usuarios->rol == 'Camarista' || $usuarios->rol == 'Supervisor' || $usuarios->rol == 'Gerente'): ?>
                                                    <tr>
                                                        <td style="display: none;"><?php echo e($usuarios->id); ?></td>
                                                        <td><?php echo e($usuarios->name); ?></td>
                                                        <td><?php echo e($usuarios->email); ?></td>
                                                        <td><?php echo e($usuarios->hotel); ?></td>
                                                        <td>
                                                            <?php if(!empty($usuarios->getRoleNames())): ?>
                                                                <?php $__currentLoopData = $usuarios->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolNombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <h5><span class="badge badge-dark"><?php echo e($rolNombre); ?></span>
                                                                    </h5>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </td>

                                                        <td>
                                                            <div class="btn-group">
                                                                <a class="btn btn-info"
                                                                    href="<?php echo e(route('usuarios.edit', $usuarios->id)); ?>">
                                                                    <i class="fas fa-edit"></i></a>

                                                                <?php echo Form::open([
                                                                    'method' => 'DELETE',
                                                                    'route' => ['usuarios.destroy', $usuarios->id],
                                                                    'style' => 'display:inline',
                                                                ]); ?>

                                                                <?php echo Form::button('<i class="fas fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger']); ?>

                                                                <?php echo Form::close(); ?>

                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('corporativo')): ?>
                                            <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($usuarios->rol == 'Camarista' ||
                                                    $usuarios->rol == 'Supervisor' ||
                                                    $usuarios->rol == 'Gerente' ||
                                                    $usuarios->rol == 'Corporativo'): ?>
                                                    <tr>
                                                        <td style="display: none;"><?php echo e($usuarios->id); ?></td>
                                                        <td><?php echo e($usuarios->name); ?></td>
                                                        <td><?php echo e($usuarios->email); ?></td>
                                                        <td><?php echo e($usuarios->hotel); ?></td>
                                                        <td>
                                                            <?php if(!empty($usuarios->getRoleNames())): ?>
                                                                <?php $__currentLoopData = $usuarios->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolNombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <h5><span class="badge badge-dark"><?php echo e($rolNombre); ?></span>
                                                                    </h5>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </td>

                                                        <td>
                                                            <div class="btn-group">
                                                                <a class="btn btn-info"
                                                                    href="<?php echo e(route('usuarios.edit', $usuarios->id)); ?>">
                                                                    <i class="fas fa-edit"></i></a>

                                                                <?php echo Form::open([
                                                                    'method' => 'DELETE',
                                                                    'route' => ['usuarios.destroy', $usuarios->id],
                                                                    'style' => 'display:inline',
                                                                ]); ?>

                                                                <?php echo Form::button('<i class="fas fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger']); ?>

                                                                <?php echo Form::close(); ?>

                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                    <?php endif; ?>
                                    
                                </tbody>
                            </table>
                            <!-- Centramos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                                <?php echo $usuario->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_tickets\resources\views/usuarios/index.blade.php ENDPATH**/ ?>