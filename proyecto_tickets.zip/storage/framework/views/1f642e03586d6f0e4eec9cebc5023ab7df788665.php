<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Crear Camarista</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-danger"><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('camaristas.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('todos_hoteles')): ?>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="hotel">Hotel</label>
                                                <select name="hotel" class="selectsearch">
                                                    <option disabled selected value="">Selecciona Hotel</option>
                                                    <?php $__currentLoopData = $hotele; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hoteles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option name="hotel" value="<?php echo e($hoteles->nombre_hotel); ?>"><?php echo e($hoteles->nombre_hotel); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </select>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('por_hotel')): ?>
                                    <div hidden>
                                        <?php $__currentLoopData = $hoteles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input value="<?php echo e($hotel->nombre_hotel); ?>" type="text" name="hotel" class="form-control">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="camarista">Camarista</label>
                                            <input type="text" name="camarista" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="status">Status</label>
                                        <select name="status" class="selectsearch">
                                            <option disabled selected value="">Selecciona Status</option>
                                            <option name="status" value="Activo">Activo</option>
                                            <option name="status" value="Inactivo">Inactivo</option>
                                          </select>
                                    </div>
                                    <button type="submit" class="btn btn-info">Guardar</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_tickets\resources\views/camaristas/crear.blade.php ENDPATH**/ ?>